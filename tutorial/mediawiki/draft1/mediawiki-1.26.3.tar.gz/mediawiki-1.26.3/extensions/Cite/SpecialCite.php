<?php

trigger_error(
	'Special:Cite was moved to a separate CiteThisPage extension, ' .
	'see <https://www.mediawiki.org/wiki/Extension:CiteThisPage> for information on how to install it',
	E_USER_WARNING
);
